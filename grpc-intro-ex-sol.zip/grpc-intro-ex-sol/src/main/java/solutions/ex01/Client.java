package solutions.ex01;

import io.grpc.*;

public class Client {
    public static void main(String[] args) throws Exception {
        final ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:8000")
                .usePlaintext()
                .build();

        GreetingServiceGrpc.GreetingServiceBlockingStub stub = GreetingServiceGrpc.newBlockingStub(channel);
        Ex01GreetingService.HelloRequest request = Ex01GreetingService.HelloRequest.newBuilder()
                .setName("1st message")
                .build();

        Ex01GreetingService.HelloResponse response = stub.greeting(request);
        System.out.println(response);

        Ex01GreetingService.HelloRequest request2 =Ex01GreetingService.HelloRequest.newBuilder()
                        .setName("2nd MESSAGE")
                        .addHobbies("JAVA")
                        .addHobbies("PYTHON")
                        .addHobbies("CHALLENGES")
                        .build();

        Ex01GreetingService.HelloResponse response2 = stub.greeting(request2);
        System.out.println(response2);

        channel.shutdownNow();
    }
}
