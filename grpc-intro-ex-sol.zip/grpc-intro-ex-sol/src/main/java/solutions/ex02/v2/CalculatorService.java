package solutions.ex02.v2;


import com.google.protobuf.Empty;
import io.grpc.stub.StreamObserver;

import java.util.ArrayList;
import java.util.List;

public class CalculatorService extends CalculatorServiceGrpc.CalculatorServiceImplBase {

    List<String> operations = new ArrayList<>();

    @Override
    public void add(Ex02CalculatorServiceV2.CalculatorRequest request, StreamObserver<Ex02CalculatorServiceV2.CalculatorResponse> responseObserver) {

        double result = request.getArg1() + request.getArg2();

        String op = String.format("%,.2f + %,.2f = %,.2f", request.getArg1(), request.getArg2(), result);
        System.out.println(op);
        operations.add(op);

        Ex02CalculatorServiceV2.CalculatorResponse response = buildResponse(result);
        responseObserver.onNext(response);

        // When you are done, you must call onCompleted.
        responseObserver.onCompleted();
    }



    @Override
    public void sub(Ex02CalculatorServiceV2.CalculatorRequest request, StreamObserver<Ex02CalculatorServiceV2.CalculatorResponse> responseObserver) {

        double result = request.getArg1() - request.getArg2();
        String op = String.format("%,.2f - %,.2f = %,.2f", request.getArg1(), request.getArg2(), result);
        System.out.println(op);
        operations.add(op);

        Ex02CalculatorServiceV2.CalculatorResponse response = buildResponse(result);

        responseObserver.onNext(response);

        // When you are done, you must call onCompleted.
        responseObserver.onCompleted();
    }

    @Override
    public void mul(Ex02CalculatorServiceV2.CalculatorRequest request, StreamObserver<Ex02CalculatorServiceV2.CalculatorResponse> responseObserver) {

        double result = request.getArg1() * request.getArg2();
        String op = String.format("%,.2f * %,.2f = %,.2f", request.getArg1(), request.getArg2(), result);
        System.out.println(op);
        operations.add(op);

        Ex02CalculatorServiceV2.CalculatorResponse response = buildResponse(result);

        responseObserver.onNext(response);

        // When you are done, you must call onCompleted.
        responseObserver.onCompleted();
    }

    @Override
    public void div(Ex02CalculatorServiceV2.CalculatorRequest request, StreamObserver<Ex02CalculatorServiceV2.CalculatorResponse> responseObserver) {

        double result = request.getArg1() / request.getArg2();
        String op = String.format("%,.2f / %,.2f = %,.2f", request.getArg1(), request.getArg2(), result);
        System.out.println(op);
        operations.add(op);

        Ex02CalculatorServiceV2.CalculatorResponse response = buildResponse(result);

        responseObserver.onNext(response);

        // When you are done, you must call onCompleted.
        responseObserver.onCompleted();
    }


    @Override
    public void listOperations(Empty request, StreamObserver<Ex02CalculatorServiceV2.OperationResponse> responseObserver) {
          System.out.println("listOperations");

        for (var current_op: operations)
        {
            System.out.println(current_op);

            Ex02CalculatorServiceV2.OperationResponse response = Ex02CalculatorServiceV2.OperationResponse.newBuilder().setOperation(current_op).build();
            responseObserver.onNext(response);
        }

        // When you are done, you must call onCompleted.
        responseObserver.onCompleted();
    }

    private Ex02CalculatorServiceV2.CalculatorResponse buildResponse(double result) {
        return Ex02CalculatorServiceV2.CalculatorResponse.newBuilder().setResult(result).build();
    }
}
