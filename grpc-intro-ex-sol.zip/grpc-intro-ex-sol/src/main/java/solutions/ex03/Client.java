package solutions.ex03;

import com.google.protobuf.Empty;
import com.google.protobuf.Timestamp;
import solutions.ex03.HighscoreServiceGrpc;
import solutions.ex03.Ex03HighscoreService;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.List;

public class Client {
    public static void main(String[] args) throws Exception {
        // Channel is the abstraction to connect to a service endpoint
        // Let's use plaintext communication because we don't have certs
        final ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:7777")
                .usePlaintext()
                .build();

        HighscoreServiceGrpc.HighscoreServiceBlockingStub stub = HighscoreServiceGrpc.newBlockingStub(channel);
        Ex03HighscoreService.Highscore highscore = createHighscore("Michael", 7271, 7);
        Ex03HighscoreService.HighscoreRequest request = Ex03HighscoreService.HighscoreRequest.newBuilder().
        setNewEntry(highscore).build();
        stub.registerHighscore(request);

        stub.dumpHighscores(Empty.getDefaultInstance());

        Ex03HighscoreService.Highscore highscore2 = createHighscore("Peter", 2312, 2);
        Ex03HighscoreService.HighscoreRequest request2 = Ex03HighscoreService.HighscoreRequest.newBuilder().
                setNewEntry(highscore2).build();
        stub.registerHighscore(request2);

        Ex03HighscoreService.Highscore highscore3 = createHighscore("Michael", 1727, 1);
        Ex03HighscoreService.HighscoreRequest request3 = Ex03HighscoreService.HighscoreRequest.newBuilder().
                setNewEntry(highscore3).build();
        stub.registerHighscore(request3);

        stub.dumpHighscores(Empty.getDefaultInstance());

        Ex03HighscoreService.HighscoreListRequest listRequest = Ex03HighscoreService.HighscoreListRequest.newBuilder().setFilterString("Michael").build();
        Ex03HighscoreService.HighscoreListResponse listResponse = stub.getAllHighscores(listRequest);
        List<Ex03HighscoreService.Highscore> entriesList = listResponse.getEntriesList();
        for (Ex03HighscoreService.Highscore curHighscore : entriesList) {
            System.out.println(curHighscore);
        }

        // A Channel should be shutdown before stopping the process.
        channel.shutdownNow();
    }

    private static Ex03HighscoreService.Highscore createHighscore(String name, int points, int level) {
        Ex03HighscoreService.Highscore highscore = Ex03HighscoreService.Highscore.newBuilder().
                setName(name).setPoints(points).setLevel(level).setDate(Timestamp.newBuilder().setSeconds(1234567).build()).build();
        return highscore;
    }
}
