package solutions.ex02.v2;


import com.google.protobuf.Empty;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.Iterator;

public class Client {
    public static void main(String[] args) throws Exception {
        final ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:11111")
                .usePlaintext()
                .build();

        CalculatorServiceGrpc.CalculatorServiceBlockingStub stub = CalculatorServiceGrpc.newBlockingStub(channel);
        Ex02CalculatorServiceV2.CalculatorRequest request =
                Ex02CalculatorServiceV2.CalculatorRequest.newBuilder().
                setArg1(7).setArg2(2).build();
        stub.add(request);

        Ex02CalculatorServiceV2.CalculatorRequest request2 =
                Ex02CalculatorServiceV2.CalculatorRequest.newBuilder().
                        setArg1(7).setArg2(2).build();
        stub.mul(request2);

        Ex02CalculatorServiceV2.CalculatorRequest request3 =
                Ex02CalculatorServiceV2.CalculatorRequest.newBuilder().
                        setArg1(72).setArg2(21).build();
        stub.div(request3);

        System.out.println("Receiving Operations");
        Iterator<Ex02CalculatorServiceV2.OperationResponse> it = stub.listOperations(Empty.getDefaultInstance());
        while (it.hasNext())
        {
            Ex02CalculatorServiceV2.OperationResponse response = it.next();
            System.out.println(response.getOperation());
        }

        channel.shutdownNow();
    }
}
