package solutions.ex02.v1;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class Client {
    public static void main(String[] args) throws Exception {
        final ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:11111")
                .usePlaintext()
                .build();

        CalculatorServiceGrpc.CalculatorServiceBlockingStub stub = CalculatorServiceGrpc.newBlockingStub(channel);
        Ex02CalculatorServiceV1.CalculatorRequest request = Ex02CalculatorServiceV1.CalculatorRequest.newBuilder().
                setArg1(7).setArg2(2).build();
        Ex02CalculatorServiceV1.CalculatorResponse response = stub.add(request);
        System.out.println(response);

        Ex02CalculatorServiceV1.CalculatorRequest request2 = Ex02CalculatorServiceV1.CalculatorRequest.newBuilder().
                setArg1(7).setArg2(2).build();
        Ex02CalculatorServiceV1.CalculatorResponse response2 = stub.mul(request2);
        System.out.println(response2);

        // A Channel should be shutdown before stopping the process.
        channel.shutdownNow();
    }
}
