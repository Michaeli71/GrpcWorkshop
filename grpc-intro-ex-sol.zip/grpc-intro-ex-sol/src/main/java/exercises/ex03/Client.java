package exercises.ex03;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class Client {
    public static void main(String[] args) throws Exception {
        final ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:7777")
                .usePlaintext()
                .build();

        // TODO: create stub

        // TODO: register highscore

        // TODO: list all highscore

        channel.shutdownNow();
    }
}
