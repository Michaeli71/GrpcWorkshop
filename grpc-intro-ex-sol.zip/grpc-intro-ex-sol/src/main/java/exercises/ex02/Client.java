package exercises.ex02;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class Client {
    public static void main(String[] args) throws Exception {
        // Channel is the abstraction to connect to a service endpoint
        // Let's use plaintext communication because we don't have certs
        final ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:8080")
                .usePlaintext()
                .build();

        // TODO: create stub

        // TODO: perform add

        // TODO: perform mult

        // TODO: show all previous operations

        // A Channel should be shutdown before stopping the process.
        channel.shutdownNow();
    }
}
