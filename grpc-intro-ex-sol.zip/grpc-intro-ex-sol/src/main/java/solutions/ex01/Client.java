package solutions.ex01;

import io.grpc.*;

public class Client {
    public static void main(String[] args) throws Exception {
        final ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:8000")
                .usePlaintext()
                .build();

        GreetingServiceGrpc.GreetingServiceBlockingStub stub = GreetingServiceGrpc.newBlockingStub(channel);
        var request = Ex01GreetingService.HelloRequest.newBuilder()
                .setName("Urs 1")
                .addHobbies("Tennis")
                .addHobbies("Theater")
                .build();

        var response = stub.greeting(request);
        System.out.println(response);

        var request2 =Ex01GreetingService.HelloRequest.newBuilder()
                        .setName("Urs 2")
                        .addHobbies("JAVA")
                        .addHobbies("PYTHON")
                        .addHobbies("CHALLENGES")
                        .build();

        var response2 = stub.greeting(request2);
        System.out.println(response2);

        channel.shutdownNow();
    }
}
