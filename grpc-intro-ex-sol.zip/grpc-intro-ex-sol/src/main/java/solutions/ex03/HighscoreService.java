package solutions.ex03;

import com.google.protobuf.Empty;
import io.grpc.stub.StreamObserver;

import java.util.ArrayList;
import java.util.List;

public class HighscoreService extends HighscoreServiceGrpc.HighscoreServiceImplBase {

    List<Ex03HighscoreService.Highscore> highscores = new ArrayList<>();

    @Override
    public void registerHighscore(Ex03HighscoreService.HighscoreRequest request, StreamObserver<Ex03HighscoreService.HighscoreResponse> responseObserver) {

        System.out.println("registerHighscore");
        var highScore = request.getNewEntry();
        highscores.add(highScore);

        Ex03HighscoreService.HighscoreResponse response = Ex03HighscoreService.HighscoreResponse.newBuilder().setAdded(true).setPos(highscores.size() - 1).build();
        responseObserver.onNext(response);

        // When you are done, you must call onCompleted.
        responseObserver.onCompleted();
    }

    @Override
    public void getAllHighscores(Ex03HighscoreService.HighscoreListRequest request, StreamObserver<Ex03HighscoreService.HighscoreListResponse> responseObserver) {

        System.out.println("getAllHighscores");

        Ex03HighscoreService.HighscoreListResponse response = Ex03HighscoreService.HighscoreListResponse.newBuilder().addAllEntries(highscores).build();
        responseObserver.onNext(response);

        // When you are done, you must call onCompleted.
        responseObserver.onCompleted();
    }

    @Override
    public void getTop10Highscores(Empty request, StreamObserver<Ex03HighscoreService.HighscoreListResponse> responseObserver) {

        List<Ex03HighscoreService.Highscore> top10 = highscores.subList(0, 10);

        Ex03HighscoreService.HighscoreListResponse response = Ex03HighscoreService.HighscoreListResponse.newBuilder().addAllEntries(top10).build();
        responseObserver.onNext(response);

        // When you are done, you must call onCompleted.
        responseObserver.onCompleted();
    }

    @Override
    public void dumpHighscores(Empty request, StreamObserver<Empty> responseObserver) {

        System.out.println("dumpHighscores");

        for (var highScore: highscores)
            System.out.println(highScore);

        responseObserver.onNext(Empty.getDefaultInstance());
        // When you are done, you must call onCompleted.
        responseObserver.onCompleted();
    }
}
