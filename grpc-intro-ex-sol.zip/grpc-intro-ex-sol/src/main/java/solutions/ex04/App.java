package solutions.ex04;

import io.grpc.Server;
import io.grpc.ServerBuilder;

public class App
{
    public static void main( String[] args ) throws Exception
    {
      Server server = ServerBuilder.forPort(12345)
        .addService(new OrderService())
        .build();

      server.start();

      System.out.println("Server started");
      server.awaitTermination();
    }
}