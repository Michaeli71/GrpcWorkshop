package exercises.ex01;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class Client {
    public static void main(String[] args) throws Exception {
        // Channel is the abstraction to connect to a service endpoint
        // Let's use plaintext communication because we don't have certs
        final ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:8080")
                .usePlaintext()
                .build();

        // TODO: create stub

        // TODO: call method with stub

        // TODO:  performa a second call

        // A Channel should be shutdown before stopping the process.
        channel.shutdownNow();
    }
}
