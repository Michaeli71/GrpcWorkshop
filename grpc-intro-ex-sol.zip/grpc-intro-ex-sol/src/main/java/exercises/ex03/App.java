package exercises.ex03;

import io.grpc.Server;
import io.grpc.ServerBuilder;

public class App
{
    public static void main( String[] args ) throws Exception
    {
      Server server = ServerBuilder.forPort(7777)
        //.addService(new HighscoreService())
        .build();

      server.start();

      System.out.println("Server started");
      server.awaitTermination();
    }
}