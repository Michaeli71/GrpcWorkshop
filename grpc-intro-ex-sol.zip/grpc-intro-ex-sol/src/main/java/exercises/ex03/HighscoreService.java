package exercises.ex03;

public class HighscoreService
{
    // TODO
}
