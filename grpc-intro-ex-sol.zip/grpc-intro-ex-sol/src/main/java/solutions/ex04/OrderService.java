package solutions.ex04;

import io.grpc.stub.StreamObserver;

public class OrderService extends OrderServiceGrpc.OrderServiceImplBase {
    @Override
    public void placeOrder(OrderRequest request, StreamObserver<OrderResponse> responseObserver) {

        System.out.println("Receiving request " + request);
        OrderResponse response = OrderResponse.newBuilder().
                setInfo("ORDER CONFIRMED").setOrderDate("17.05.2022")
                .build();
        System.out.println("Sending response " + response);
        responseObserver.onNext(response);

        // When you are done, you must call onCompleted.
        responseObserver.onCompleted();
    }
}
