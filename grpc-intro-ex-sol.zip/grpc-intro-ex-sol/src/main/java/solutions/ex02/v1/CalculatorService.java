package solutions.ex02.v1;


import io.grpc.stub.StreamObserver;

import java.util.ArrayList;
import java.util.List;

public class CalculatorService extends CalculatorServiceGrpc.CalculatorServiceImplBase {

    @Override
    public void add(Ex02CalculatorServiceV1.CalculatorRequest request, StreamObserver<Ex02CalculatorServiceV1.CalculatorResponse> responseObserver) {

        double result = request.getArg1() + request.getArg2();

        System.out.println(String.format("%,.2f + %,.2f = %,.2f", request.getArg1(), request.getArg2(), result));

        Ex02CalculatorServiceV1.CalculatorResponse response = buildResponse(result);
        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }


    @Override
    public void sub(Ex02CalculatorServiceV1.CalculatorRequest request, StreamObserver<Ex02CalculatorServiceV1.CalculatorResponse> responseObserver) {

        double result = request.getArg1() - request.getArg2();

        System.out.println(String.format("%,.2f - %,.2f = %,.2f", request.getArg1(), request.getArg2(), result));

        Ex02CalculatorServiceV1.CalculatorResponse response = buildResponse(result);

        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }

    @Override
    public void mul(Ex02CalculatorServiceV1.CalculatorRequest request, StreamObserver<Ex02CalculatorServiceV1.CalculatorResponse> responseObserver) {


        double result = request.getArg1() * request.getArg2();
        System.out.println(String.format("%,.2f * %,.2f = %,.2f", request.getArg1(), request.getArg2(), result));

        Ex02CalculatorServiceV1.CalculatorResponse response = buildResponse(result);

        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }

    @Override
    public void div(Ex02CalculatorServiceV1.CalculatorRequest request, StreamObserver<Ex02CalculatorServiceV1.CalculatorResponse> responseObserver) {

        double result = request.getArg1() / request.getArg2();
        System.out.println(String.format("%,.2f / %,.2f = %,.2f", request.getArg1(), request.getArg2(), result));

        Ex02CalculatorServiceV1.CalculatorResponse response = buildResponse(result);
        System.out.println(response);

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    private Ex02CalculatorServiceV1.CalculatorResponse buildResponse(double result) {
        return Ex02CalculatorServiceV1.CalculatorResponse.newBuilder().setResult(result).build();
    }
}
