package exercises.ex01;

import io.grpc.stub.StreamObserver;

public class GreetingService
{
    // TODO
}
