package solutions.ex04;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class Client {
    public static void main(String[] args) throws Exception {
        final ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:12345")
                .usePlaintext()
                .build();

        OrderServiceGrpc.OrderServiceBlockingStub stub = OrderServiceGrpc.newBlockingStub(channel);
        OrderRequest request = OrderRequest.newBuilder().setProduct("Einfach Java").
                setAmount(42).setEmail("MI@CHA.EL").build();

        OrderResponse response = stub.placeOrder(request);
        System.out.println(response);

        OrderResponse response2 = stub.placeOrder(request);
        System.out.println(response2);

        channel.shutdownNow();
    }
}
