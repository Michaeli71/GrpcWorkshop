package solutions.ex01;

import io.grpc.stub.StreamObserver;

public class GreetingService extends GreetingServiceGrpc.GreetingServiceImplBase {
    @Override
    public void greeting(Ex01GreetingService.HelloRequest request,
                         StreamObserver<Ex01GreetingService.HelloResponse> responseObserver) {

        System.out.println(request);

        Ex01GreetingService.HelloResponse response = Ex01GreetingService.HelloResponse.newBuilder()
                .setGreeting("Hello there, " + request.getName() + " / " + request.getHobbiesList())
                .build();

        responseObserver.onNext(response);

        responseObserver.onCompleted();
    }
}
